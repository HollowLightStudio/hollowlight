const btnPlay = document.getElementById('btnPlay');
const btnRestart = document.getElementById('btnRestart');

function syncButtons() {
  btnPlay.style.display    = (gameState === 'menu') ? 'block' : 'none';
  btnRestart.style.display = (gameState === 'win' || gameState === 'lose') ? 'block' : 'none';
}

function drawText(text, x, y, font, color, shadow) {
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = font;
  ctx.fillStyle = color;
  if (shadow) { ctx.shadowColor = shadow; ctx.shadowBlur = 10; }
  else { ctx.shadowBlur = 0; }
  ctx.fillText(text, x, y);
  ctx.shadowBlur = 0;
}

function drawMenu() {
  drawText('САПЁР', W / 2, H / 2 - 120, 'bold 56px Arial, sans-serif', '#E5E7EB', '#F59E0B');
  drawText('НОЧНАЯ СМЕНА', W / 2, H / 2 - 65, 'bold 18px Arial, sans-serif', 'rgba(229,231,235,0.6)', null);
  drawText('Hollow Light Studio | v0.3', W / 2, H - 30, '14px Arial, sans-serif', 'rgba(229,231,235,0.35)', null);
}

function drawHUD() {
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = '#E5E7EB';
  ctx.font = 'bold 22px Arial, sans-serif';
  ctx.fillText(`💣 ${MINES_COUNT - flagsUsed}`, 20, 20);

  ctx.textAlign = 'right';
  ctx.fillText(`🚩 ${flagsUsed}/${MINES_COUNT}`, W - 20, 20);
}

function drawGrid() {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const cell = grid[r][c];
      const x = gridStartX + c * CELL_SIZE;
      const y = gridStartY + r * CELL_SIZE;

      // ✅ Новая палитра клеток
      if (cell.isRevealed) {
        if (cell.isMine) {
          // мина: тёмная с красной вспышкой при взрыве
          ctx.fillStyle = (gameState === 'lose') ? '#DC2626' : '#111827';
        } else {
          ctx.fillStyle = '#1F2937';           // открытая пустая
        }
      } else {
        ctx.fillStyle = '#374151';             // закрытая
      }
      ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);

      ctx.strokeStyle = '#0D1117';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);

      // ✅ Шрифт цифр — монospace
      ctx.font = 'bold 24px "JetBrains Mono", Consolas, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const cx = x + CELL_SIZE / 2;
      const cy = y + CELL_SIZE / 2;

      if (cell.isRevealed && cell.isMine) {
        ctx.fillStyle = '#E5E7EB';
        ctx.fillText('💣', cx, cy);
      } else if (cell.isRevealed && cell.neighbors > 0) {
        ctx.fillStyle = numberColor(cell.neighbors);
        ctx.fillText(cell.neighbors, cx, cy);
      } else if (!cell.isRevealed && cell.isFlagged) {
        ctx.fillText('🚩', cx, cy);
      }
    }
  }
}

// ✅ Новые цвета цифр
function numberColor(n) {
  switch (n) {
    case 1: return '#60A5FA';
    case 2: return '#34D399';
    case 3: return '#F87171';
    case 4: return '#A78BFA';
    case 5: return '#FBBF24';
    case 6: return '#22D3EE';
    case 7: return '#F472B6';
    case 8: return '#D1D5DB';
    default: return '#E5E7EB';
  }
}

function drawDarkness() {
  ctx.save();

  const gradient = ctx.createRadialGradient(
    mouseX, mouseY, LIGHT_RADIUS * 0.2,
    mouseX, mouseY, LIGHT_RADIUS
  );
  gradient.addColorStop(0, 'rgba(0,0,0,0)');
  gradient.addColorStop(0.6, 'rgba(0,0,0,0.8)');
  gradient.addColorStop(1, 'rgba(0,0,0,0.98)');

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, W, H);

  ctx.beginPath();
  ctx.arc(mouseX, mouseY, 5, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(245,158,11,0.8)';   // ✅ янтарный огонёк
  ctx.fill();

  ctx.restore();
}

function drawEndScreen() {
  ctx.fillStyle = 'rgba(0,0,0,0.8)';
  ctx.fillRect(0, 0, W, H);

  if (gameState === 'win') {
    drawText('ПОБЕДА!', W / 2, H / 2 - 120, 'bold 56px Arial, sans-serif', '#34D399', '#34D399');
    drawText('Все мины найдены', W / 2, H / 2 - 50, 'bold 22px Arial, sans-serif', '#E5E7EB', null);
  } else {
    drawText('ВЗРЫВ!', W / 2, H / 2 - 120, 'bold 56px Arial, sans-serif', '#DC2626', '#DC2626');
    drawText('Ты наступил на мину', W / 2, H / 2 - 50, 'bold 22px Arial, sans-serif', '#E5E7EB', null);
  }
}

btnPlay.addEventListener('click', async () => {
  try {
    if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
  } catch (e) {}
  try {
    if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('portrait');
  } catch (e) {}
  resize();
  mouseX = W / 2;
  mouseY = H / 2;
  startGame();
});

btnRestart.addEventListener('click', () => {
  mouseX = W / 2;
  mouseY = H / 2;
  startGame();
});