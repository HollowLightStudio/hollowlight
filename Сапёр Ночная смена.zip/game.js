const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

// ===== Resize =====
function resize() {
  DPR = window.devicePixelRatio || 1;
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width  = Math.floor(W * DPR);
  canvas.height = Math.floor(H * DPR);
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';
  ctx.imageSmoothingEnabled = true;

  const maxCellW = (W - 40) / COLS;
  const maxCellH = (H - 160) / ROWS;
  CELL_SIZE = Math.floor(Math.min(maxCellW, maxCellH));

  const totalW = COLS * CELL_SIZE;
  const totalH = ROWS * CELL_SIZE;
  gridStartX = (W - totalW) / 2;
  gridStartY = (H - totalH) / 2;

  // если фонарик ещё не двигали — в центр
  if (mouseX === 0 && mouseY === 0) {
    mouseX = W / 2;
    mouseY = H / 2;
  }
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 100));
resize();

// ===== Инициализация поля =====
function initGrid() {
  grid = [];
  flagsUsed = 0;

  for (let r = 0; r < ROWS; r++) {
    const row = [];
    for (let c = 0; c < COLS; c++) {
      row.push({ isMine: false, isRevealed: false, isFlagged: false, neighbors: 0 });
    }
    grid.push(row);
  }

  let minesPlaced = 0;
  while (minesPlaced < MINES_COUNT) {
    const r = Math.floor(Math.random() * ROWS);
    const c = Math.floor(Math.random() * COLS);
    if (!grid[r][c].isMine) {
      grid[r][c].isMine = true;
      minesPlaced++;
    }
  }

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      if (grid[r][c].isMine) continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && grid[nr][nc].isMine) count++;
        }
      }
      grid[r][c].neighbors = count;
    }
  }
}

// ===== Старт =====
function startGame() {
  initGrid();
  gameStartTime = Date.now();
  shakeTimer = 0;
  canvas.style.transform = 'translate(0,0)';
  gameState = 'playing';
  syncButtons();
}

// ===== Открытие клетки =====
function revealCell(r, c) {
  if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
  if (grid[r][c].isRevealed || grid[r][c].isFlagged) return;

  grid[r][c].isRevealed = true;

  if (grid[r][c].isMine) {
    gameState = 'lose';
    shakeTimer = 20;
    syncButtons();
    return;
  }

  if (grid[r][c].neighbors === 0) {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr !== 0 || dc !== 0) revealCell(r + dr, c + dc);
      }
    }
  }
}

// ===== Флажок =====
function toggleFlag(r, c) {
  if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
  const cell = grid[r][c];
  if (cell.isRevealed) return;
  if (!cell.isFlagged && flagsUsed >= MINES_COUNT) return;
  cell.isFlagged = !cell.isFlagged;
  flagsUsed += cell.isFlagged ? 1 : -1;
  checkWin();
}

// ===== Победа =====
function checkWin() {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const cell = grid[r][c];
      if (cell.isMine) { if (!cell.isFlagged) return; }
      else { if (!cell.isRevealed) return; }
    }
  }
  gameState = 'win';
  syncButtons();
}

// ===== Координаты → клетка =====
function cellFromCoords(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const x = (clientX - rect.left) * (W / rect.width);
  const y = (clientY - rect.top) * (H / rect.height);
  const c = Math.floor((x - gridStartX) / CELL_SIZE);
  const r = Math.floor((y - gridStartY) / CELL_SIZE);
  if (r >= 0 && r < ROWS && c >= 0 && c < COLS) return { r, c };
  return null;
}

function inLight(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const x = (clientX - rect.left) * (W / rect.width);
  const y = (clientY - rect.top) * (H / rect.height);
  const dx = x - mouseX;
  const dy = y - mouseY;
  return (dx * dx + dy * dy) <= LIGHT_RADIUS * LIGHT_RADIUS;
}

// ===== Тап / долгий тап =====
let touchStartTime = 0;
let touchStartX = 0;
let touchStartY = 0;
let longPressTimer = null;
let touchHandled = false;
let touchStartCell = null;

const MOVE_TOLERANCE = 10;   // пикселей движения — уже не «тап»

canvas.addEventListener('touchstart', (e) => {
  e.preventDefault();
  if (gameState !== 'playing') return;

  const touch = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  mouseX = (touch.clientX - rect.left) * (W / rect.width);
  mouseY = (touch.clientY - rect.top) * (H / rect.height);

  touchStartTime = Date.now();
  touchStartX = touch.clientX;
  touchStartY = touch.clientY;
  touchHandled = false;
  touchStartCell = cellFromCoords(touch.clientX, touch.clientY);

  if (touchStartCell && inLight(touch.clientX, touch.clientY)) {
    const { r, c } = touchStartCell;
    longPressTimer = setTimeout(() => {
      const dx = Math.abs(touchStartX - touch.clientX);
      const dy = Math.abs(touchStartY - touch.clientY);
      if (dx < MOVE_TOLERANCE && dy < MOVE_TOLERANCE) {
        touchHandled = true;
        toggleFlag(r, c);
      }
    }, 500);
  }
}, { passive: false });

canvas.addEventListener('touchmove', (e) => {
  e.preventDefault();
  if (gameState !== 'playing') return;

  const touch = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  mouseX = (touch.clientX - rect.left) * (W / rect.width);
  mouseY = (touch.clientY - rect.top) * (H / rect.height);

  const dx = Math.abs(touchStartX - touch.clientX);
  const dy = Math.abs(touchStartY - touch.clientY);
  if (dx > MOVE_TOLERANCE || dy > MOVE_TOLERANCE) {
    clearTimeout(longPressTimer);
    touchHandled = true;
  }
}, { passive: false });

canvas.addEventListener('touchend', (e) => {
  e.preventDefault();
  if (gameState !== 'playing') return;
  clearTimeout(longPressTimer);
  if (touchHandled) return;

  const touch = e.changedTouches[0];
  const dx = Math.abs(touchStartX - touch.clientX);
  const dy = Math.abs(touchStartY - touch.clientY);
  const duration = Date.now() - touchStartTime;

  if (duration < 500 && dx < MOVE_TOLERANCE && dy < MOVE_TOLERANCE) {
    if (!inLight(touch.clientX, touch.clientY)) return;
    const cell = cellFromCoords(touch.clientX, touch.clientY);
    if (cell && !grid[cell.r][cell.c].isFlagged) {
      revealCell(cell.r, cell.c);
      checkWin();
    }
  }
}, { passive: false });

canvas.addEventListener('touchcancel', () => clearTimeout(longPressTimer));

// ===== ПК: мышь =====
canvas.addEventListener('mousemove', (e) => {
  if (gameState !== 'playing') return;
  const rect = canvas.getBoundingClientRect();
  mouseX = (e.clientX - rect.left) * (W / rect.width);
  mouseY = (e.clientY - rect.top) * (H / rect.height);
});

canvas.addEventListener('mousedown', (e) => {
  if (gameState !== 'playing') return;
  const cell = cellFromCoords(e.clientX, e.clientY);
  if (!cell || !inLight(e.clientX, e.clientY)) return;
  if (e.button === 2) {
    e.preventDefault();
    toggleFlag(cell.r, cell.c);
  } else if (e.button === 0) {
    if (!grid[cell.r][cell.c].isFlagged) {
      revealCell(cell.r, cell.c);
      checkWin();
    }
  }
});
canvas.addEventListener('contextmenu', (e) => e.preventDefault());

// ===== Update (тряска) =====
function update() {
  if (shakeTimer > 0) {
    shakeTimer--;
    const dx = Math.random() * 10 - 5;
    const dy = Math.random() * 10 - 5;
    canvas.style.transform = `translate(${dx}px, ${dy}px)`;
    if (shakeTimer === 0) canvas.style.transform = 'translate(0,0)';
  }
}

// ===== Draw =====
function draw() {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  ctx.imageSmoothingEnabled = true;

  if (gameState === 'menu') {
    ctx.fillStyle = '#0D1117';
    ctx.fillRect(0, 0, W, H);
    drawMenu();
    return;
  }

  ctx.fillStyle = '#0D1117';
  ctx.fillRect(0, 0, W, H);

  drawHUD();
  drawGrid();
  drawDarkness();

  if (gameState === 'win' || gameState === 'lose') drawEndScreen();
}

// ===== Цикл =====
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

syncButtons();
requestAnimationFrame(loop);