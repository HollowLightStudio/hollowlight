// ===== Размеры =====
let W = 0, H = 0, DPR = 1;

// ===== Поле =====
const COLS = 10;
const ROWS = 8;
const MINES_COUNT = 10;
let CELL_SIZE = 50;

// ===== Состояние =====
// 'menu' | 'playing' | 'win' | 'lose'
let gameState = 'menu';
let grid = [];
let gameStartTime = 0;
let flagsUsed = 0;

// ===== Геометрия поля =====
let gridStartX = 0;
let gridStartY = 0;

// ===== ✅ Фонарик =====
let mouseX = 0;
let mouseY = 0;
const LIGHT_RADIUS = 120;

// ===== ✅ Тряска =====
let shakeTimer = 0;